#!/usr/bin/env python3
"""Concatenate MP4 clips into one video (bundled static ffmpeg — no system install).

Usage:
  concat_video.py a.mp4 b.mp4 c.mp4 --out final.mp4
  concat_video.py --glob 'clips/*.mp4' --out final.mp4
Strategy: concat demuxer + stream copy (clips must share codec/size);
falls back to re-encode if copy fails. Adds +faststart for web/YouTube.
Exit: 0 = written (prints duration + size), 1 = fail.
"""
import argparse
import glob
import re
import subprocess
import sys
import tempfile
from pathlib import Path


def ff() -> str:
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def probe(path: Path) -> float:
    r = subprocess.run([ff(), "-i", str(path)], capture_output=True, text=True)
    m = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", r.stderr)
    if not m:
        return -1.0
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("clips", nargs="*")
    ap.add_argument("--glob", default=None, help="glob pattern instead of args")
    ap.add_argument("--out", default="final.mp4")
    args = ap.parse_args()

    clips = [Path(c) for c in args.clips]
    if args.glob:
        clips += [Path(p) for p in sorted(glob.glob(args.glob))]
    clips = [c for c in clips if c.exists()]
    if len(clips) < 2:
        print(f"need >=2 clips, got {len(clips)}", file=sys.stderr)
        return 1

    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as fh:
        for c in clips:
            fh.write(f"file '{c.resolve()}'\n")
        listfile = fh.name

    out = Path(args.out)
    # 1) stream copy (fast)
    cmd = [ff(), "-y", "-f", "concat", "-safe", "0", "-i", listfile,
           "-c", "copy", "-movflags", "+faststart", str(out)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    # 2) fallback re-encode
    if r.returncode != 0:
        print("stream-copy failed → re-encoding...", file=sys.stderr)
        cmd = [ff(), "-y", "-f", "concat", "-safe", "0", "-i", listfile,
               "-c:v", "libx264", "-crf", "18", "-preset", "veryfast",
               "-c:a", "aac", "-movflags", "+faststart", str(out)]
        r = subprocess.run(cmd, capture_output=True, text=True)
    Path(listfile).unlink(missing_ok=True)
    if r.returncode != 0 or not out.exists():
        print((r.stdout + r.stderr)[-400:], file=sys.stderr)
        return 1

    dur = probe(out)
    # full decode sanity check
    dec = subprocess.run([ff(), "-v", "error", "-i", str(out), "-f", "null", "-"],
                         capture_output=True, text=True)
    ok = dec.returncode == 0 and not dec.stderr.strip()
    print(f"wrote {out} — {int(dur // 60)}:{int(dur % 60):02d}, "
          f"{out.stat().st_size // 1024} KB, {len(clips)} clips, "
          f"decode {'clean ✅' if ok else 'ERRORS ❌'}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
